package com.my.newproject9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import androidx.cardview.widget.CardView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import android.widget.TextView;
import android.widget.ImageView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.widget.ScrollView;
import de.hdodenhof.circleimageview.*;
import android.view.View;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MenuActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private FloatingActionButton _fab;
	private DrawerLayout _drawer;
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear2;
	private BottomNavigationView bottomnavigation1;
	private LinearLayout linear3;
	private LinearLayout bottom1;
	private LinearLayout bottom2;
	private LinearLayout bottom3;
	private LinearLayout bottom4;
	private LinearLayout linear19;
	private LinearLayout pager_cont;
	private CardView cardview3;
	private LinearLayout cod;
	private TabLayout tabLayout;
	private LinearLayout base1;
	private LinearLayout trash;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private TextView textview1;
	private ImageView imageview1;
	private SwipeRefreshLayout swiperefreshlayout1;
	private RecyclerView recyclerview1;
	private GridView gridview1;
	private SwipeRefreshLayout swiperefreshlayout2;
	private RecyclerView recyclerview2;
	private GridView gridview2;
	private RecyclerView recyclerview5;
	private RecyclerView recyclerview4;
	private TextView textview11;
	private RecyclerView recyclerview6;
	private LinearLayout linear8;
	private ImageView imageview5;
	private TextView textview3;
	private LinearLayout linear9;
	private ScrollView vscroll1;
	private CardView cardview1;
	private LinearLayout linear12;
	private CircleImageView circleimageview1;
	private LinearLayout linear13;
	private ImageView qrc_image;
	private TextView textview4;
	private TextView textview5;
	private LinearLayout linear11;
	private LinearLayout finance_linear;
	private RecyclerView recyclerview3;
	private CardView cardview2;
	private LinearLayout linear14;
	private TextView textview6;
	private TextView textview7;
	private LinearLayout linear16;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private ImageView imageview7;
	private TextView textview8;
	private ImageView imageview8;
	private TextView textview9;
	private ImageView imageview9;
	private TextView textview10;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear4;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_linear5;
	private LinearLayout _drawer_linear6;
	private CircleImageView _drawer_circleimageview1;
	private TextView _drawer_textview1;
	private TextView _drawer_textview2;
	private ImageView _drawer_imageview2;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview3;
	private TextView _drawer_textview4;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.menu);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_fab = (FloatingActionButton) findViewById(R.id._fab);
		
		_drawer = (DrawerLayout) findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(MenuActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		bottomnavigation1 = (BottomNavigationView) findViewById(R.id.bottomnavigation1);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		bottom1 = (LinearLayout) findViewById(R.id.bottom1);
		bottom2 = (LinearLayout) findViewById(R.id.bottom2);
		bottom3 = (LinearLayout) findViewById(R.id.bottom3);
		bottom4 = (LinearLayout) findViewById(R.id.bottom4);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		pager_cont = (LinearLayout) findViewById(R.id.pager_cont);
		cardview3 = (CardView) findViewById(R.id.cardview3);
		cod = (LinearLayout) findViewById(R.id.cod);
		tabLayout = (TabLayout) findViewById(R.id.tabLayout);
		base1 = (LinearLayout) findViewById(R.id.base1);
		trash = (LinearLayout) findViewById(R.id.trash);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		layout2 = (LinearLayout) findViewById(R.id.layout2);
		layout3 = (LinearLayout) findViewById(R.id.layout3);
		layout4 = (LinearLayout) findViewById(R.id.layout4);
		layout5 = (LinearLayout) findViewById(R.id.layout5);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		swiperefreshlayout1 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout1);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		gridview1 = (GridView) findViewById(R.id.gridview1);
		swiperefreshlayout2 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout2);
		recyclerview2 = (RecyclerView) findViewById(R.id.recyclerview2);
		gridview2 = (GridView) findViewById(R.id.gridview2);
		recyclerview5 = (RecyclerView) findViewById(R.id.recyclerview5);
		recyclerview4 = (RecyclerView) findViewById(R.id.recyclerview4);
		textview11 = (TextView) findViewById(R.id.textview11);
		recyclerview6 = (RecyclerView) findViewById(R.id.recyclerview6);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		qrc_image = (ImageView) findViewById(R.id.qrc_image);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		finance_linear = (LinearLayout) findViewById(R.id.finance_linear);
		recyclerview3 = (RecyclerView) findViewById(R.id.recyclerview3);
		cardview2 = (CardView) findViewById(R.id.cardview2);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = (LinearLayout) _nav_view.findViewById(R.id.linear2);
		_drawer_linear4 = (LinearLayout) _nav_view.findViewById(R.id.linear4);
		_drawer_linear3 = (LinearLayout) _nav_view.findViewById(R.id.linear3);
		_drawer_linear5 = (LinearLayout) _nav_view.findViewById(R.id.linear5);
		_drawer_linear6 = (LinearLayout) _nav_view.findViewById(R.id.linear6);
		_drawer_circleimageview1 = (CircleImageView) _nav_view.findViewById(R.id.circleimageview1);
		_drawer_textview1 = (TextView) _nav_view.findViewById(R.id.textview1);
		_drawer_textview2 = (TextView) _nav_view.findViewById(R.id.textview2);
		_drawer_imageview2 = (ImageView) _nav_view.findViewById(R.id.imageview2);
		_drawer_textview3 = (TextView) _nav_view.findViewById(R.id.textview3);
		_drawer_imageview3 = (ImageView) _nav_view.findViewById(R.id.imageview3);
		_drawer_textview4 = (TextView) _nav_view.findViewById(R.id.textview4);
		
		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(MenuItem item) {
				final int _itemId = item.getItemId();
				if (_itemId == 0) {
					bottom1.setVisibility(View.GONE);
					bottom3.setVisibility(View.GONE);
					bottom4.setVisibility(View.GONE);
					bottom2.setVisibility(View.VISIBLE);
				}
				if (_itemId == 1) {
					bottom2.setVisibility(View.GONE);
					bottom3.setVisibility(View.GONE);
					bottom4.setVisibility(View.GONE);
					bottom1.setVisibility(View.VISIBLE);
				}
				if (_itemId == 2) {
					bottom1.setVisibility(View.GONE);
					bottom2.setVisibility(View.GONE);
					bottom4.setVisibility(View.GONE);
					bottom3.setVisibility(View.VISIBLE);
				}
				if (_itemId == 3) {
					bottom1.setVisibility(View.GONE);
					bottom2.setVisibility(View.GONE);
					bottom3.setVisibility(View.GONE);
					bottom4.setVisibility(View.VISIBLE);
				}
				return true;
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "in progress");
			}
		});
	}
	
	private void initializeLogic() {
		bottom1.setVisibility(View.GONE);
		_tab();
		for(int _repeat10 = 0; _repeat10 < (int)(15); _repeat10++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", String.valueOf((long)(SketchwareUtil.getRandom((int)(1), (int)(7)))));
				listmap.add(_item);
			}
			
		}
		recyclerview6.setLayoutManager(new LinearLayoutManager(this));
		recyclerview6.setAdapter(new Recyclerview6Adapter(listmap));
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		recyclerview1.setAdapter(new Recyclerview1Adapter(listmap));
		bottomnavigation1.getMenu().add(0, 0, 0, "Holligram").setIcon(R.drawable.menu_contacts);
		bottomnavigation1.getMenu().add(0, 1, 0, "ChatUpp").setIcon(R.drawable.ic_comment_white);
		bottomnavigation1.getMenu().add(0, 2, 0, "Notifications").setIcon(R.drawable.ic_notifications_none_white);
		bottomnavigation1.getMenu().add(0, 3, 0, "Profile").setIcon(R.drawable.ic_account_circle_white);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuItem menuitem1 = menu.add(Menu.NONE, 0, Menu.NONE, "profile");
		menuitem1.setIcon(R.drawable.ic_search_white);
		menuitem1.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 1, 0, "Profile");
		menu.add(0, 2, 0, "Settings");
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
		public boolean onOptionsItemSelected(MenuItem item){
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
		
		return super.onOptionsItemSelected(item);
	}
	
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	public void _tab () {
		viewPager = new androidx.viewpager.widget.ViewPager(this); viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); 
		
		MyPagerAdapter adapter = new MyPagerAdapter(); viewPager.setAdapter(adapter); viewPager.setCurrentItem(0); base1.addView(viewPager);
		 
		tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#9c27b0"));
		 tabLayout.setTabTextColors(Color.parseColor("#000000"), Color.parseColor("#9c27b0")); 
		
		
		 tabLayout.setupWithViewPager(viewPager);
		 
	} private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter { public int getCount() { return 4; } @Override public Object instantiateItem(ViewGroup collection, int position) { LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); View v = inflater.inflate(R.layout.empty, null);
			
			 LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) { ViewGroup parent = (ViewGroup) layout1.getParent(); if (parent != null) { parent.removeView(layout1); 
					
				}container.addView(layout1); 
				
			} else if (position == 1) { ViewGroup parent = (ViewGroup) layout2.getParent(); if (parent != null) { parent.removeView(layout2);
					
				} container.addView(layout2);
				
				 } else if (position == 2) { ViewGroup parent = (ViewGroup) layout3.getParent(); if (parent != null) { parent.removeView(layout3);
					
				} container.addView(layout3); 
				
			} else if (position == 3) { ViewGroup parent = (ViewGroup) layout4.getParent(); if (parent != null) { parent.removeView(layout4);
					
				} container.addView(layout4); }
			
			else if (position == 4) { ViewGroup parent = (ViewGroup) layout5.getParent(); if (parent != null) { parent.removeView(layout5);
					
				} container.addView(layout5); }
			
			
			
			 collection.addView(v, 0); return v; 
			
		} @Override public void destroyItem(ViewGroup collection, int position, Object view) { collection.removeView((View) view); trash.addView((View) view);
			
		} @Override public CharSequence getPageTitle(int position) { switch (position) { case 0: return "CHATS"; case 1: return "STATUS"; case 2: return "GROUPS";
				case 3: return "CALLS";
				case 4: return "QUOTES";
				 default: return null; }
			
			
		} @Override public boolean isViewFromObject(View arg0, Object arg1) { return arg0 == ((View) arg1);} @Override public Parcelable saveState() { return null; } } androidx.viewpager.widget.ViewPager viewPager;  private void foo() {
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.chat, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView card = (androidx.cardview.widget.CardView) _view.findViewById(R.id.card);
			final LinearLayout body = (LinearLayout) _view.findViewById(R.id.body);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final TextView username = (TextView) _view.findViewById(R.id.username);
			final ImageView verified = (ImageView) _view.findViewById(R.id.verified);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final TextView time = (TextView) _view.findViewById(R.id.time);
			final TextView msg = (TextView) _view.findViewById(R.id.msg);
			final LinearLayout tool_linear = (LinearLayout) _view.findViewById(R.id.tool_linear);
			final LinearLayout message_tools = (LinearLayout) _view.findViewById(R.id.message_tools);
			final LinearLayout tools_body = (LinearLayout) _view.findViewById(R.id.tools_body);
			final ImageView message_open_close_menu = (ImageView) _view.findViewById(R.id.message_open_close_menu);
			final ImageView message_call = (ImageView) _view.findViewById(R.id.message_call);
			final ImageView message_message = (ImageView) _view.findViewById(R.id.message_message);
			final ImageView message_delete = (ImageView) _view.findViewById(R.id.message_delete);
			
			if (_position == 0) {
				username.setText("Eliman🥰");
			}
			if (_position == 1) {
				username.setText("Joy🤗");
			}
			if (_position == 2) {
				username.setText("Jonathan");
			}
			if (_position == 3) {
				username.setText("Grace❤️");
			}
			if (_position == 4) {
				username.setText("Emmanuel🤗");
			}
			if (_position == 5) {
				username.setText("Peace🥰");
			}
			if (_position == 6) {
				username.setText("Andrew🤗");
			}
			if (_position == 7) {
				username.setText("Chioma🤗");
			}
			if (_position == 8) {
				username.setText("Chimezie🤗");
			}
			if (_position == 9) {
				username.setText("Ayomide🤗");
			}
			if (_position == 10) {
				username.setText("Bamidele");
			}
			if (_position == 11) {
				username.setText("Ifeoma");
			}
			if (_position == 12) {
				username.setText("Joy🤗");
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear62 = (LinearLayout) _view.findViewById(R.id.linear62);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear70 = (LinearLayout) _view.findViewById(R.id.linear70);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview5Adapter extends RecyclerView.Adapter<Recyclerview5Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview5Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear62 = (LinearLayout) _view.findViewById(R.id.linear62);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear70 = (LinearLayout) _view.findViewById(R.id.linear70);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview6Adapter extends RecyclerView.Adapter<Recyclerview6Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview6Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear62 = (LinearLayout) _view.findViewById(R.id.linear62);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear70 = (LinearLayout) _view.findViewById(R.id.linear70);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			
			style5.setVisibility(View.GONE);
			style4.setVisibility(View.GONE);
			style3.setVisibility(View.GONE);
			video.setVisibility(View.GONE);
			plus_image.setVisibility(View.INVISIBLE);
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 1) {
				rightside3.setVisibility(View.GONE);
				style3.setVisibility(View.VISIBLE);
				leftside3image.setImageResource(R.drawable.oyor);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 3) {
				rightside3.setVisibility(View.VISIBLE);
				style3.setVisibility(View.VISIBLE);
				leftside3image.setImageResource(R.drawable.theophilus);
				rightside3down.setImageResource(R.drawable.theophilus);
				rightside3up.setImageResource(R.drawable.oyor);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 2) {
				down4.setVisibility(View.GONE);
				style4.setVisibility(View.VISIBLE);
				up4right.setImageResource(R.drawable.theophilus);
				up4left.setImageResource(R.drawable.oyor);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 4) {
				down4.setVisibility(View.VISIBLE);
				style4.setVisibility(View.VISIBLE);
				up4right.setImageResource(R.drawable.theophilus);
				up4left.setImageResource(R.drawable.oyor);
				down4right.setImageResource(R.drawable.theophilus);
				down4left.setImageResource(R.drawable.oyor);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 5) {
				style5.setVisibility(View.VISIBLE);
				plus_image.setVisibility(View.INVISIBLE);
				leftside5upp.setImageResource(R.drawable.theophilus);
				leftside5downn.setImageResource(R.drawable.oyor);
				rightside5up.setImageResource(R.drawable.theophilus);
				rightside5middle.setImageResource(R.drawable.oyor);
				rightside5down.setImageResource(R.drawable.oyor);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) > 5) {
				style5.setVisibility(View.VISIBLE);
				plus_image.setVisibility(View.VISIBLE);
				leftside5upp.setImageResource(R.drawable.theophilus);
				leftside5downn.setImageResource(R.drawable.oyor);
				rightside5up.setImageResource(R.drawable.theophilus);
				rightside5middle.setImageResource(R.drawable.oyor);
				rightside5down.setImageResource(R.drawable.oyor);
				plus_image.setText("+ ".concat(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("key").toString()) - 5)).concat(" more")));
				plus_image.setBackgroundColor(0x60000000);
			}
			if (_data.get((int)_position).get("key").toString().equals("video")) {
				video.setVisibility(View.VISIBLE);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview3Adapter extends RecyclerView.Adapter<Recyclerview3Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear62 = (LinearLayout) _view.findViewById(R.id.linear62);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear70 = (LinearLayout) _view.findViewById(R.id.linear70);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}