package com.my.newproject9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.ScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.EditText;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.graphics.Typeface;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class MainActivity extends  AppCompatActivity  { 
	
	
	private boolean login_mode = false;
	
	private ScrollView scroll;
	private LinearLayout linear_main;
	private TextView tx_title;
	private TextView tx_subtitle;
	private LinearLayout l_name;
	private LinearLayout l_email;
	private LinearLayout l_pass;
	private LinearLayout button_continue;
	private LinearLayout div;
	private LinearLayout button_mode;
	private LinearLayout div2;
	private LinearLayout lin_more;
	private ImageView im_name;
	private EditText tx_name;
	private ImageView im_email;
	private EditText tx_email;
	private ImageView im_pass;
	private EditText tx_password;
	private ImageView im_forget_pass;
	private TextView button_text;
	private LinearLayout devider1;
	private TextView tx_inf;
	private LinearLayout devider2;
	private TextView tx_mode;
	private LinearLayout div3;
	private TextView tx_inf2;
	private LinearLayout div4;
	private LinearLayout l_google;
	private LinearLayout linear3;
	private LinearLayout l_fb;
	private LinearLayout linear4;
	private LinearLayout l_twitter;
	private ImageView im_google;
	private ImageView im_fb;
	private ImageView im_twitter;
	
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		scroll = (ScrollView) findViewById(R.id.scroll);
		linear_main = (LinearLayout) findViewById(R.id.linear_main);
		tx_title = (TextView) findViewById(R.id.tx_title);
		tx_subtitle = (TextView) findViewById(R.id.tx_subtitle);
		l_name = (LinearLayout) findViewById(R.id.l_name);
		l_email = (LinearLayout) findViewById(R.id.l_email);
		l_pass = (LinearLayout) findViewById(R.id.l_pass);
		button_continue = (LinearLayout) findViewById(R.id.button_continue);
		div = (LinearLayout) findViewById(R.id.div);
		button_mode = (LinearLayout) findViewById(R.id.button_mode);
		div2 = (LinearLayout) findViewById(R.id.div2);
		lin_more = (LinearLayout) findViewById(R.id.lin_more);
		im_name = (ImageView) findViewById(R.id.im_name);
		tx_name = (EditText) findViewById(R.id.tx_name);
		im_email = (ImageView) findViewById(R.id.im_email);
		tx_email = (EditText) findViewById(R.id.tx_email);
		im_pass = (ImageView) findViewById(R.id.im_pass);
		tx_password = (EditText) findViewById(R.id.tx_password);
		im_forget_pass = (ImageView) findViewById(R.id.im_forget_pass);
		button_text = (TextView) findViewById(R.id.button_text);
		devider1 = (LinearLayout) findViewById(R.id.devider1);
		tx_inf = (TextView) findViewById(R.id.tx_inf);
		devider2 = (LinearLayout) findViewById(R.id.devider2);
		tx_mode = (TextView) findViewById(R.id.tx_mode);
		div3 = (LinearLayout) findViewById(R.id.div3);
		tx_inf2 = (TextView) findViewById(R.id.tx_inf2);
		div4 = (LinearLayout) findViewById(R.id.div4);
		l_google = (LinearLayout) findViewById(R.id.l_google);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		l_fb = (LinearLayout) findViewById(R.id.l_fb);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		l_twitter = (LinearLayout) findViewById(R.id.l_twitter);
		im_google = (ImageView) findViewById(R.id.im_google);
		im_fb = (ImageView) findViewById(R.id.im_fb);
		im_twitter = (ImageView) findViewById(R.id.im_twitter);
		
		button_continue.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), MenuActivity.class);
				startActivity(i);
			}
		});
		
		button_mode.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (login_mode) {
					_Mode(false);
				}
				else {
					_Mode(true);
				}
			}
		});
	}
	
	private void initializeLogic() {
		_UI();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _rippleRoundStroke (final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _Shadow (final double _sadw, final double _cru, final String _wc, final View _widgets) {
		android.graphics.drawable.GradientDrawable wd = new android.graphics.drawable.GradientDrawable();
		wd.setColor(Color.parseColor(_wc));
		wd.setCornerRadius((int)_cru);
		_widgets.setElevation((int)_sadw);
		_widgets.setBackground(wd);
	}
	
	
	public void _UI () {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) { getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR); }
		getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
		getWindow().setNavigationBarColor(Color.parseColor("#FFFFFF"));
		scroll.setVerticalScrollBarEnabled(false);
		_Shadow(0, 100, "#EEEEEE", l_email);
		_Shadow(0, 100, "#EEEEEE", l_pass);
		_Shadow(0, 100, "#EEEEEE", l_name);
		tx_email.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		tx_password.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		button_text.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		tx_inf.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		tx_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/blogger_sans_bold.ttf"), 0);
		tx_subtitle.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		tx_mode.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		tx_inf2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/notosans.ttf"), 0);
		im_email.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		im_pass.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		im_forget_pass.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		im_name.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		_Mode(true);
		_rippleRoundStroke(button_continue, "#00BCD4", "#9c27b0", 100, 0, "#00BCD4");
		_rippleRoundStroke(button_mode, "#EEEEEE", "#BDBDBD", 100, 0, "#EEEEEE");
		_rippleRoundStroke(im_forget_pass, "#EEEEEE", "#BDBDBD", 100, 0, "#EEEEEE");
		_rippleRoundStroke(l_google, "#EEEEEE", "#BDBDBD", 100, 0, "#EEEEEE");
		_rippleRoundStroke(l_fb, "#EEEEEE", "#BDBDBD", 100, 0, "#EEEEEE");
		_rippleRoundStroke(l_twitter, "#EEEEEE", "#BDBDBD", 100, 0, "#EEEEEE");
	}
	
	
	public void _Mode (final boolean _login) {
		login_mode = _login;
		_TransitionManager(linear_main, 200);
		if (_login) {
			l_name.setVisibility(View.GONE);
			tx_title.setText("Welcome, Sign In");
			tx_subtitle.setText("Login into your account to continue");
			tx_mode.setText("Create new account");
			im_forget_pass.setVisibility(View.VISIBLE);
			tx_email.requestFocus();
		}
		else {
			l_name.setVisibility(View.VISIBLE);
			tx_title.setText("Welcome, Sign Up");
			tx_subtitle.setText("Let's create your free account");
			tx_mode.setText("Already have an account");
			im_forget_pass.setVisibility(View.GONE);
			tx_name.requestFocus();
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}