package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class ViewActivity extends  AppCompatActivity  { 
	
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout recycler;
	private LinearLayout viewpager;
	private LinearLayout video;
	private RecyclerView recyclerview1;
	private ViewPager viewpager1;
	private VideoView videoview1;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.view);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		recycler = (LinearLayout) findViewById(R.id.recycler);
		viewpager = (LinearLayout) findViewById(R.id.viewpager);
		video = (LinearLayout) findViewById(R.id.video);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		viewpager1 = (ViewPager) findViewById(R.id.viewpager1);
		videoview1 = (VideoView) findViewById(R.id.videoview1);
		MediaController videoview1_controller = new MediaController(this);
		videoview1.setMediaController(videoview1_controller);
	}
	
	private void initializeLogic() {
		_FullScreen();
		for(int _repeat15 = 0; _repeat15 < (int)(50); _repeat15++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "");
				list.add(_item);
			}
			
		}
		recyclerview1.setAdapter(new Recyclerview1Adapter(list));
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		SnapHelper snapHelper = new PagerSnapHelper();
		snapHelper.attachToRecyclerView(recyclerview1);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _FullScreen () {
		//code by LORD_HOSSEIN
		if (Build.VERSION.SDK_INT >= 19 && Build.VERSION.SDK_INT < 21) {
					    setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
					            | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, true);
		}
		if (Build.VERSION.SDK_INT >= 19) {
					    getWindow().getDecorView().setSystemUiVisibility(
					            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
					                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
					                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
					    );
		}
		if (Build.VERSION.SDK_INT >= 21) {
					    setWindowFlag(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS
					            | WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION, false);
					    getWindow().setStatusBarColor(Color.TRANSPARENT);
					    getWindow().setNavigationBarColor(Color.TRANSPARENT);
		}
	}
	private void setWindowFlag(final int bits, boolean on) {
		    Window win = getWindow();
		    WindowManager.LayoutParams winParams = win.getAttributes();
		    if (on) {
					        winParams.flags |= bits;
					    } else {
					        winParams.flags &= ~bits;
					    }
		    win.setAttributes(winParams);
	}
	{
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.postc, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout bbar = (LinearLayout) _view.findViewById(R.id.bbar);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final LinearLayout linear79 = (LinearLayout) _view.findViewById(R.id.linear79);
			final LinearLayout linear81 = (LinearLayout) _view.findViewById(R.id.linear81);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview44 = (ImageView) _view.findViewById(R.id.imageview44);
			final TextView textview44 = (TextView) _view.findViewById(R.id.textview44);
			final TextView textview46 = (TextView) _view.findViewById(R.id.textview46);
			final ImageView imageview46 = (ImageView) _view.findViewById(R.id.imageview46);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}