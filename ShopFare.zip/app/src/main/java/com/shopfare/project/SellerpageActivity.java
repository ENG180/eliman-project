package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import android.widget.LinearLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import android.widget.ImageView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import android.widget.TextView;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import android.view.View;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.widget.NestedScrollView;

public class SellerpageActivity extends  AppCompatActivity  { 
	
	public final int REQ_CD_FP = 101;
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private double n = 0;
	private double nn = 0;
	private  Color cll;
	private String vat = "";
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listm = new ArrayList<>();
	
	private CollapsingToolbarLayout collapsingtoolbar1;
	private LinearLayout cod;
	private LinearLayout linear3;
	private LinearLayout linear1;
	private BottomNavigationView bottomnavigation1;
	private ImageView imageview5;
	private TabLayout tabLayout;
	private LinearLayout base;
	private LinearLayout trash;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear5;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private ImageView imageview2;
	private TextView textview2;
	private ImageView imageview3;
	private TextView textview3;
	private ImageView imageview4;
	private TextView textview4;
	private LinearLayout linear6;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private LinearLayout layout6;
	private TextView textview1;
	private ImageView imageview1;
	private RecyclerView recyclerview1;
	private RecyclerView recyclerview3;
	private GridView gridview3;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sellerpage);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		collapsingtoolbar1 = (CollapsingToolbarLayout) findViewById(R.id.collapsingtoolbar1);
		cod = (LinearLayout) findViewById(R.id.cod);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		bottomnavigation1 = (BottomNavigationView) findViewById(R.id.bottomnavigation1);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		tabLayout = (TabLayout) findViewById(R.id.tabLayout);
		base = (LinearLayout) findViewById(R.id.base);
		trash = (LinearLayout) findViewById(R.id.trash);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		textview2 = (TextView) findViewById(R.id.textview2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		textview3 = (TextView) findViewById(R.id.textview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		layout2 = (LinearLayout) findViewById(R.id.layout2);
		layout3 = (LinearLayout) findViewById(R.id.layout3);
		layout4 = (LinearLayout) findViewById(R.id.layout4);
		layout5 = (LinearLayout) findViewById(R.id.layout5);
		layout6 = (LinearLayout) findViewById(R.id.layout6);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		recyclerview3 = (RecyclerView) findViewById(R.id.recyclerview3);
		gridview3 = (GridView) findViewById(R.id.gridview3);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(MenuItem item) {
				final int _itemId = item.getItemId();
				if (_itemId == 1) {
					i.setClass(getApplicationContext(), StoreinfoActivity.class);
					startActivity(i);
				}
				return true;
			}
		});
		
		imageview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), StoreinfoActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		_tab();
		for(int _repeat10 = 0; _repeat10 < (int)(50); _repeat10++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "collapsing items");
				listm.add(_item);
			}
			
		}
		recyclerview1.setLayoutManager(new GridLayoutManager(this,2,LinearLayoutManager.VERTICAL,false));
		recyclerview1.setAdapter(new Recyclerview1Adapter(listm));
		linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)0, 0xFFFFFFFF, 0xFFBDBDBD));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)0, 0xFFFFFFFF, 0xFFBDBDBD));
		linear5.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)0, 0xFFFFFFFF, 0xFFFFFFFF));
		linear8.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)0, 0xFFFFFFFF, 0xFFBDBDBD));
		imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		bottomnavigation1.getMenu().add(0, 0, 0, "Content").setIcon(R.drawable.ic_add_shopping_cart_white);
		bottomnavigation1.getMenu().add(0, 1, 0, "Store Info").setIcon(R.drawable.ic_assignment_turned_in_white);
		bottomnavigation1.getMenu().add(0, 2, 0, "Deliveries").setIcon(R.drawable.ic_add_shopping_cart_white);
		collapsingtoolbar1.setFitsSystemWindows(true);
		collapsingtoolbar1.setTitleEnabled(true);
		collapsingtoolbar1.setTitle("Supreme Luxury");
		collapsingtoolbar1.setCollapsedTitleTextColor(0xFFFFFFFF);
		collapsingtoolbar1.setExpandedTitleColor(0xFFFFFFFF);
		collapsingtoolbar1.setContentScrimColor(0x80000000);
		collapsingtoolbar1.setScrimsShown(true, false);
		collapsingtoolbar1.setExpandedTitleGravity(Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM);
		collapsingtoolbar1.setScrimAnimationDuration(500);
		Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/roboto_regular.ttf"); 
		collapsingtoolbar1.setCollapsedTitleTypeface(tf); 
		collapsingtoolbar1.setExpandedTitleTypeface(tf); 
		
		_toolbar.setBackgroundColor(Color.TRANSPARENT);
		_NavStatusBarColor("4caf50", "4caf50");
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuItem menuitem1 = menu.add(Menu.NONE, 0, Menu.NONE, "Search");
		menuitem1.setIcon(R.drawable.ic_search_white);
		menuitem1.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 1, 0, "Sort List");
		menu.add(0, 2, 0, "Cart List");
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
		public boolean onOptionsItemSelected(MenuItem item){
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
		
		return super.onOptionsItemSelected(item);
	}
	public void _NavStatusBarColor (final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _tab () {
		viewPager = new androidx.viewpager.widget.ViewPager(this); viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); 
		
		MyPagerAdapter adapter = new MyPagerAdapter(); viewPager.setAdapter(adapter); viewPager.setCurrentItem(0); base.addView(viewPager);
		 
		tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#4caf50"));
		 tabLayout.setTabTextColors(Color.parseColor("#212121"), Color.parseColor("#4caf50")); 
		
		
		 tabLayout.setupWithViewPager(viewPager);
		 
	} private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter { public int getCount() { return 6; } @Override public Object instantiateItem(ViewGroup collection, int position) { LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); View v = inflater.inflate(R.layout.empty, null);
			
			 LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) { ViewGroup parent = (ViewGroup) layout1.getParent(); if (parent != null) { parent.removeView(layout1); 
					
				}container.addView(layout1); 
				
			} else if (position == 1) { ViewGroup parent = (ViewGroup) layout2.getParent(); if (parent != null) { parent.removeView(layout2);
					
				} container.addView(layout2);
				
				 } else if (position == 2) { ViewGroup parent = (ViewGroup) layout3.getParent(); if (parent != null) { parent.removeView(layout3);
					
				} container.addView(layout3); 
				
			} else if (position == 3) { ViewGroup parent = (ViewGroup) layout4.getParent(); if (parent != null) { parent.removeView(layout4);
					
				} container.addView(layout4); }
			
			else if (position == 4) { ViewGroup parent = (ViewGroup) layout5.getParent(); if (parent != null) { parent.removeView(layout5);
					
				} container.addView(layout5); }
			
			else if (position == 5) { ViewGroup parent = (ViewGroup) layout6.getParent(); if (parent != null) { parent.removeView(layout6);
					
				} container.addView(layout6); }
			
			
			
			 collection.addView(v, 0); return v; 
			
		} @Override public void destroyItem(ViewGroup collection, int position, Object view) { collection.removeView((View) view); trash.addView((View) view);
			
		} @Override public CharSequence getPageTitle(int position) { switch (position) { case 0: return "SNEAKERS"; case 1: return "WRIST WATCHES"; case 2: return "BODY CREAMS";
				case 3: return "HANDBAG";
				case 4: return "PERFUME";
				case 5: return "NECKLACE";
				 default: return null; }
			
			
		} @Override public boolean isViewFromObject(View arg0, Object arg1) { return arg0 == ((View) arg1);} @Override public Parcelable saveState() { return null; } } androidx.viewpager.widget.ViewPager viewPager;  private void foo() {
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.cust4, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView hc2 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc2);
			final LinearLayout hh2 = (LinearLayout) _view.findViewById(R.id.hh2);
			final ImageView imageview7 = (ImageView) _view.findViewById(R.id.imageview7);
			final TextView textview14 = (TextView) _view.findViewById(R.id.textview14);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview20 = (TextView) _view.findViewById(R.id.textview20);
			final TextView textview21 = (TextView) _view.findViewById(R.id.textview21);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview3Adapter extends RecyclerView.Adapter<Recyclerview3Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.custom2, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Gridview3Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom1, null);
			}
			
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			
			
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}