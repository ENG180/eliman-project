package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import android.widget.ScrollView;
import androidx.cardview.widget.CardView;
import android.widget.TextView;
import android.widget.ImageView;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class FinanceActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	
	private LinearLayout linear1;
	private BottomNavigationView bottomnavigation1;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear10;
	private LinearLayout linear87;
	private LinearLayout linear93;
	private CardView cardview2;
	private LinearLayout linear14;
	private TextView textview6;
	private TextView textview7;
	private LinearLayout linear16;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private ImageView imageview7;
	private TextView textview8;
	private ImageView imageview8;
	private TextView textview9;
	private ImageView imageview9;
	private TextView textview10;
	private CardView cardview5;
	private LinearLayout linear88;
	private TextView textview54;
	private TextView textview55;
	private LinearLayout linear89;
	private LinearLayout linear90;
	private LinearLayout linear91;
	private LinearLayout linear92;
	private ImageView imageview20;
	private TextView textview56;
	private ImageView imageview21;
	private TextView textview57;
	private ImageView imageview22;
	private TextView textview58;
	private CardView cardview6;
	private LinearLayout linear94;
	private TextView textview59;
	private TextView textview60;
	private LinearLayout linear95;
	private LinearLayout linear96;
	private LinearLayout linear97;
	private LinearLayout linear98;
	private ImageView imageview23;
	private TextView textview61;
	private ImageView imageview24;
	private TextView textview62;
	private ImageView imageview25;
	private TextView textview63;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.finance);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		bottomnavigation1 = (BottomNavigationView) findViewById(R.id.bottomnavigation1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		linear87 = (LinearLayout) findViewById(R.id.linear87);
		linear93 = (LinearLayout) findViewById(R.id.linear93);
		cardview2 = (CardView) findViewById(R.id.cardview2);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		cardview5 = (CardView) findViewById(R.id.cardview5);
		linear88 = (LinearLayout) findViewById(R.id.linear88);
		textview54 = (TextView) findViewById(R.id.textview54);
		textview55 = (TextView) findViewById(R.id.textview55);
		linear89 = (LinearLayout) findViewById(R.id.linear89);
		linear90 = (LinearLayout) findViewById(R.id.linear90);
		linear91 = (LinearLayout) findViewById(R.id.linear91);
		linear92 = (LinearLayout) findViewById(R.id.linear92);
		imageview20 = (ImageView) findViewById(R.id.imageview20);
		textview56 = (TextView) findViewById(R.id.textview56);
		imageview21 = (ImageView) findViewById(R.id.imageview21);
		textview57 = (TextView) findViewById(R.id.textview57);
		imageview22 = (ImageView) findViewById(R.id.imageview22);
		textview58 = (TextView) findViewById(R.id.textview58);
		cardview6 = (CardView) findViewById(R.id.cardview6);
		linear94 = (LinearLayout) findViewById(R.id.linear94);
		textview59 = (TextView) findViewById(R.id.textview59);
		textview60 = (TextView) findViewById(R.id.textview60);
		linear95 = (LinearLayout) findViewById(R.id.linear95);
		linear96 = (LinearLayout) findViewById(R.id.linear96);
		linear97 = (LinearLayout) findViewById(R.id.linear97);
		linear98 = (LinearLayout) findViewById(R.id.linear98);
		imageview23 = (ImageView) findViewById(R.id.imageview23);
		textview61 = (TextView) findViewById(R.id.textview61);
		imageview24 = (ImageView) findViewById(R.id.imageview24);
		textview62 = (TextView) findViewById(R.id.textview62);
		imageview25 = (ImageView) findViewById(R.id.imageview25);
		textview63 = (TextView) findViewById(R.id.textview63);
	}
	
	private void initializeLogic() {
		setTitle("Finance");
		bottomnavigation1.getMenu().add(0, 0, 0, "Dashboard").setIcon(R.drawable.ic_menu_black);
		bottomnavigation1.getMenu().add(0, 1, 0, "Transactions").setIcon(R.drawable.ic_event_note_white);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}