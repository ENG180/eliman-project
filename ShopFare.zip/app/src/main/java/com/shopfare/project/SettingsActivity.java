package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.ImageView;
import android.widget.TextView;
import de.hdodenhof.circleimageview.*;
import android.widget.Switch;
import android.app.Activity;
import android.content.SharedPreferences;
import android.content.Intent;
import android.net.Uri;
import android.widget.CompoundButton;
import android.graphics.Typeface;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class SettingsActivity extends  AppCompatActivity  { 
	
	
	private String defc = "";
	private String defrepc = "";
	private String repc = "";
	private String color = "";
	
	private LinearLayout alllin;
	private LinearLayout topbar;
	private LinearLayout line1;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private TextView textview8;
	private LinearLayout linear1;
	private TextView account_ttl;
	private LinearLayout pro_lin;
	private LinearLayout line2;
	private LinearLayout editpro_lin;
	private LinearLayout line3;
	private LinearLayout cemail_lin;
	private LinearLayout line4;
	private LinearLayout cpass_lin;
	private LinearLayout line5;
	private LinearLayout logout_lin;
	private LinearLayout line6;
	private TextView preferences_ttl;
	private LinearLayout ui_lin;
	private LinearLayout line7;
	private LinearLayout dark_lin;
	private LinearLayout line8;
	private TextView about_ttl;
	private LinearLayout v_lin;
	private LinearLayout line9;
	private LinearLayout clog_lin;
	private LinearLayout line10;
	private TextView team_ttl;
	private LinearLayout t1_lin;
	private LinearLayout line11;
	private TextView contact_ttl;
	private LinearLayout email_lin;
	private LinearLayout line12;
	private LinearLayout tele_lin;
	private LinearLayout line13;
	private TextView others_ttl;
	private LinearLayout toc_lin;
	private LinearLayout line14;
	private LinearLayout pp_lin;
	private CircleImageView circleimageview1;
	private LinearLayout linear4;
	private TextView name_txt;
	private TextView username_txt;
	private ImageView imageview4;
	private TextView textview12;
	private ImageView imageview6;
	private TextView textview15;
	private ImageView imageview7;
	private TextView textview16;
	private ImageView imageview5;
	private TextView textview14;
	private TextView textview17;
	private TextView currentcolor_txt;
	private LinearLayout linear28;
	private Switch switch1;
	private TextView textview18;
	private TextView textview19;
	private TextView version_txt;
	private TextView versionsub_txt;
	private LinearLayout linear36;
	private TextView view_all_cl;
	private TextView textview23;
	private TextView changelogsub_txt;
	private LinearLayout linear43;
	private TextView textview45;
	private TextView textview27;
	private TextView textview28;
	private TextView textview41;
	private TextView textview42;
	private TextView textview32;
	private TextView textview33;
	private TextView textview47;
	private TextView textview49;
	
	private SharedPreferences dt;
	private Intent intent = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.settings);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		alllin = (LinearLayout) findViewById(R.id.alllin);
		topbar = (LinearLayout) findViewById(R.id.topbar);
		line1 = (LinearLayout) findViewById(R.id.line1);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		textview8 = (TextView) findViewById(R.id.textview8);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		account_ttl = (TextView) findViewById(R.id.account_ttl);
		pro_lin = (LinearLayout) findViewById(R.id.pro_lin);
		line2 = (LinearLayout) findViewById(R.id.line2);
		editpro_lin = (LinearLayout) findViewById(R.id.editpro_lin);
		line3 = (LinearLayout) findViewById(R.id.line3);
		cemail_lin = (LinearLayout) findViewById(R.id.cemail_lin);
		line4 = (LinearLayout) findViewById(R.id.line4);
		cpass_lin = (LinearLayout) findViewById(R.id.cpass_lin);
		line5 = (LinearLayout) findViewById(R.id.line5);
		logout_lin = (LinearLayout) findViewById(R.id.logout_lin);
		line6 = (LinearLayout) findViewById(R.id.line6);
		preferences_ttl = (TextView) findViewById(R.id.preferences_ttl);
		ui_lin = (LinearLayout) findViewById(R.id.ui_lin);
		line7 = (LinearLayout) findViewById(R.id.line7);
		dark_lin = (LinearLayout) findViewById(R.id.dark_lin);
		line8 = (LinearLayout) findViewById(R.id.line8);
		about_ttl = (TextView) findViewById(R.id.about_ttl);
		v_lin = (LinearLayout) findViewById(R.id.v_lin);
		line9 = (LinearLayout) findViewById(R.id.line9);
		clog_lin = (LinearLayout) findViewById(R.id.clog_lin);
		line10 = (LinearLayout) findViewById(R.id.line10);
		team_ttl = (TextView) findViewById(R.id.team_ttl);
		t1_lin = (LinearLayout) findViewById(R.id.t1_lin);
		line11 = (LinearLayout) findViewById(R.id.line11);
		contact_ttl = (TextView) findViewById(R.id.contact_ttl);
		email_lin = (LinearLayout) findViewById(R.id.email_lin);
		line12 = (LinearLayout) findViewById(R.id.line12);
		tele_lin = (LinearLayout) findViewById(R.id.tele_lin);
		line13 = (LinearLayout) findViewById(R.id.line13);
		others_ttl = (TextView) findViewById(R.id.others_ttl);
		toc_lin = (LinearLayout) findViewById(R.id.toc_lin);
		line14 = (LinearLayout) findViewById(R.id.line14);
		pp_lin = (LinearLayout) findViewById(R.id.pp_lin);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		name_txt = (TextView) findViewById(R.id.name_txt);
		username_txt = (TextView) findViewById(R.id.username_txt);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview12 = (TextView) findViewById(R.id.textview12);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		textview15 = (TextView) findViewById(R.id.textview15);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview16 = (TextView) findViewById(R.id.textview16);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview14 = (TextView) findViewById(R.id.textview14);
		textview17 = (TextView) findViewById(R.id.textview17);
		currentcolor_txt = (TextView) findViewById(R.id.currentcolor_txt);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		switch1 = (Switch) findViewById(R.id.switch1);
		textview18 = (TextView) findViewById(R.id.textview18);
		textview19 = (TextView) findViewById(R.id.textview19);
		version_txt = (TextView) findViewById(R.id.version_txt);
		versionsub_txt = (TextView) findViewById(R.id.versionsub_txt);
		linear36 = (LinearLayout) findViewById(R.id.linear36);
		view_all_cl = (TextView) findViewById(R.id.view_all_cl);
		textview23 = (TextView) findViewById(R.id.textview23);
		changelogsub_txt = (TextView) findViewById(R.id.changelogsub_txt);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		textview45 = (TextView) findViewById(R.id.textview45);
		textview27 = (TextView) findViewById(R.id.textview27);
		textview28 = (TextView) findViewById(R.id.textview28);
		textview41 = (TextView) findViewById(R.id.textview41);
		textview42 = (TextView) findViewById(R.id.textview42);
		textview32 = (TextView) findViewById(R.id.textview32);
		textview33 = (TextView) findViewById(R.id.textview33);
		textview47 = (TextView) findViewById(R.id.textview47);
		textview49 = (TextView) findViewById(R.id.textview49);
		dt = getSharedPreferences("dt", Activity.MODE_PRIVATE);
		
		switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2)  {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					if (dt.getString("theme", "").equals("white")) {
						intent.setClass(getApplicationContext(), SettingsActivity.class);
						startActivity(intent);
						finish();
					}
					else {
						_dark();
					}
					dt.edit().putString("theme", "dark").commit();
				}
				else {
					dt.edit().putString("theme", "white").commit();
					_white();
				}
			}
		});
	}
	
	private void initializeLogic() {
		// #Readme#: RippleEffects moreblock is created by Arman Mohamed, credits go to him, check his tutorials on Sketchub.
		color = "#2196f3";
		_SetColorFilter(imageview5, color);
		_SetColorFilter(imageview4, color);
		_SetColorFilter(imageview6, color);
		_SetColorFilter(imageview7, color);
		_SetTextColor(account_ttl, color);
		_SetTextColor(preferences_ttl, color);
		_SetTextColor(about_ttl, color);
		_SetTextColor(team_ttl, color);
		_SetTextColor(contact_ttl, color);
		_SetTextColor(others_ttl, color);
		_SetTextColor(view_all_cl, color);
		if (dt.getString("theme", "").equals("")) {
			_white();
		}
		else {
			if (dt.getString("theme", "").equals("dark")) {
				switch1.setChecked(true);
			}
			else {
				_white();
			}
		}
		_Font();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _SetTextColor (final TextView _textview, final String _color) {
		_textview.setTextColor(Color.parseColor(_color));
	}
	
	
	public void _SetColorFilter (final ImageView _img, final String _color) {
		_img.setColorFilter(Color.parseColor(_color), PorterDuff.Mode.MULTIPLY);
	}
	
	
	public void _rippleRoundStroke (final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _white () {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
				Window w = SettingsActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
			getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		} 
		alllin.setBackgroundColor(0xFFFFFFFF);
		line1.setBackgroundColor(0xFFE0E0E0);
		line2.setBackgroundColor(0xFFE0E0E0);
		line3.setBackgroundColor(0xFFE0E0E0);
		line4.setBackgroundColor(0xFFE0E0E0);
		line5.setBackgroundColor(0xFFE0E0E0);
		line6.setBackgroundColor(0xFFE0E0E0);
		line7.setBackgroundColor(0xFFE0E0E0);
		line8.setBackgroundColor(0xFFE0E0E0);
		line9.setBackgroundColor(0xFFE0E0E0);
		line10.setBackgroundColor(0xFFE0E0E0);
		line11.setBackgroundColor(0xFFE0E0E0);
		line12.setBackgroundColor(0xFFE0E0E0);
		line13.setBackgroundColor(0xFFE0E0E0);
		line14.setBackgroundColor(0xFFE0E0E0);
		defc = "#000000";
		defrepc = "#ffffff";
		repc = "#e0e0e0";
		_SetColorFilter(imageview1, defc);
		_TextColors();
		_setRipple();
	}
	
	
	public void _dark () {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			
			Window w = SettingsActivity.this.getWindow();
				w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
				w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFF212121);
		}
		alllin.setBackgroundColor(0xFF212121);
		line1.setBackgroundColor(0xFF424242);
		line2.setBackgroundColor(0xFF424242);
		line3.setBackgroundColor(0xFF424242);
		line4.setBackgroundColor(0xFF424242);
		line5.setBackgroundColor(0xFF424242);
		line6.setBackgroundColor(0xFF424242);
		line7.setBackgroundColor(0xFF424242);
		line8.setBackgroundColor(0xFF424242);
		line9.setBackgroundColor(0xFF424242);
		line10.setBackgroundColor(0xFF424242);
		line11.setBackgroundColor(0xFF424242);
		line12.setBackgroundColor(0xFF424242);
		line13.setBackgroundColor(0xFF424242);
		line14.setBackgroundColor(0xFF424242);
		defc = "#ffffff";
		defrepc = "#212121";
		repc = "#424242";
		_SetColorFilter(imageview1, defc);
		_TextColors();
		_setRipple();
	}
	
	
	public void _setRipple () {
		_rippleRoundStroke(imageview1, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(pro_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(editpro_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(cemail_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(cpass_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(logout_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(ui_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(dark_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(v_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(clog_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(t1_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(email_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(tele_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(toc_lin, defrepc, repc, 0, 0, "#00000000");
		_rippleRoundStroke(pp_lin, defrepc, repc, 0, 0, "#00000000");
	}
	
	
	public void _TextColors () {
		_SetTextColor(textview8, defc);
		_SetTextColor(textview17, defc);
		_SetTextColor(textview14, defc);
		_SetTextColor(textview16, defc);
		_SetTextColor(textview15, defc);
		_SetTextColor(textview12, defc);
		_SetTextColor(username_txt, defc);
		_SetTextColor(name_txt, defc);
		_SetTextColor(textview33, defc);
		_SetTextColor(textview32, defc);
		_SetTextColor(textview42, defc);
		_SetTextColor(textview41, defc);
		_SetTextColor(textview28, defc);
		_SetTextColor(textview47, defc);
		_SetTextColor(textview27, defc);
		_SetTextColor(textview45, defc);
		_SetTextColor(changelogsub_txt, defc);
		_SetTextColor(textview23, defc);
		_SetTextColor(versionsub_txt, defc);
		_SetTextColor(version_txt, defc);
		_SetTextColor(textview19, defc);
		_SetTextColor(textview18, defc);
		_SetTextColor(switch1, defc);
		_SetTextColor(currentcolor_txt, defc);
		_SetTextColor(textview49, defc);
	}
	
	
	public void _Font () {
		username_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		account_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		name_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview16.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		preferences_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview17.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview18.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview19.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		about_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		version_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview23.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		view_all_cl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		team_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview27.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		contact_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview41.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview32.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		others_ttl.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview47.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		textview49.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_medium.ttf"), 0);
		versionsub_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		changelogsub_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		textview28.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		textview42.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		textview45.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
		textview33.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/roboto_regular.ttf"), 0);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}