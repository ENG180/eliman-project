package com.my.newproject9;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import android.content.Intent;
import android.net.Uri;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class HomeActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> map1 = new HashMap<>();
	private boolean search = false;
	private boolean Grid = false;
	
	private ArrayList<HashMap<String, Object>> listmap2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	
	private LinearLayout toolbar;
	private LinearLayout linear2;
	private BottomNavigationView bottomnavigation1;
	private ImageView imageview2;
	private LinearLayout linear7;
	private ImageView imageview4;
	private TextView textview2;
	private EditText edittext1;
	private ImageView imageview3;
	private LinearLayout cod;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private TabLayout tabLayout;
	private LinearLayout base;
	private LinearLayout trash;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private TextView textview1;
	private ImageView imageview1;
	private RecyclerView recyclerview1;
	private SwipeRefreshLayout swiperefreshlayout1;
	private GridView gridview1;
	private RecyclerView recyclerview2;
	private SwipeRefreshLayout swiperefreshlayout2;
	private GridView gridview2;
	private GridView gridview3;
	
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		toolbar = (LinearLayout) findViewById(R.id.toolbar);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		bottomnavigation1 = (BottomNavigationView) findViewById(R.id.bottomnavigation1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		cod = (LinearLayout) findViewById(R.id.cod);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		tabLayout = (TabLayout) findViewById(R.id.tabLayout);
		base = (LinearLayout) findViewById(R.id.base);
		trash = (LinearLayout) findViewById(R.id.trash);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		layout2 = (LinearLayout) findViewById(R.id.layout2);
		layout3 = (LinearLayout) findViewById(R.id.layout3);
		layout4 = (LinearLayout) findViewById(R.id.layout4);
		layout5 = (LinearLayout) findViewById(R.id.layout5);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		swiperefreshlayout1 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout1);
		gridview1 = (GridView) findViewById(R.id.gridview1);
		recyclerview2 = (RecyclerView) findViewById(R.id.recyclerview2);
		swiperefreshlayout2 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout2);
		gridview2 = (GridView) findViewById(R.id.gridview2);
		gridview3 = (GridView) findViewById(R.id.gridview3);
	}
	
	private void initializeLogic() {
		_toolbar.setVisibility(View.GONE);
		_tab();
		_Song3();
		map1.clear();
		_Cat1();
		_Cat2();
		SketchwareUtil.sortListMap(listmap1, "name", false, true);
		gridview2.setAdapter(new Gridview2Adapter(listmap2));
		((BaseAdapter)gridview2.getAdapter()).notifyDataSetChanged();
		gridview1.setAdapter(new Gridview1Adapter(listmap1));
		((BaseAdapter)gridview1.getAdapter()).notifyDataSetChanged();
		recyclerview2.setLayoutManager(new LinearLayoutManager(this));
		recyclerview2.setAdapter(new Recyclerview2Adapter(listmap2));
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		recyclerview1.setAdapter(new Recyclerview1Adapter(listmap1));
		bottomnavigation1.getMenu().add(0, 0, 0, "Home").setIcon(R.drawable.ic_home_white);
		bottomnavigation1.getMenu().add(0, 1, 0, "Categories").setIcon(R.drawable.ic_view_module_white);
		bottomnavigation1.getMenu().add(0, 2, 0, "Cart List").setIcon(R.drawable.ic_add_shopping_cart_white);
		bottomnavigation1.getMenu().add(0, 3, 0, "Profile").setIcon(R.drawable.ic_account_circle_white);
		imageview4.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		search = false;
		Grid = true;
		edittext1.setVisibility(View.GONE);
		recyclerview1.setVisibility(View.VISIBLE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	public void _tab () {
		viewPager = new androidx.viewpager.widget.ViewPager(this); viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); 
		
		MyPagerAdapter adapter = new MyPagerAdapter(); viewPager.setAdapter(adapter); viewPager.setCurrentItem(0); base.addView(viewPager);
		 
		tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#4caf50"));
		 tabLayout.setTabTextColors(Color.parseColor("#212121"), Color.parseColor("#4caf50")); 
		
		
		 tabLayout.setupWithViewPager(viewPager);
		 
	} private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter { public int getCount() { return 2; } @Override public Object instantiateItem(ViewGroup collection, int position) { LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); View v = inflater.inflate(R.layout.empty, null);
			
			 LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) { ViewGroup parent = (ViewGroup) layout1.getParent(); if (parent != null) { parent.removeView(layout1); 
					
				}container.addView(layout1); 
				
			} else if (position == 1) { ViewGroup parent = (ViewGroup) layout2.getParent(); if (parent != null) { parent.removeView(layout2);
					
				} container.addView(layout2);
				
				 } else if (position == 2) { ViewGroup parent = (ViewGroup) layout3.getParent(); if (parent != null) { parent.removeView(layout3);
					
				} container.addView(layout3); 
				
			} else if (position == 3) { ViewGroup parent = (ViewGroup) layout4.getParent(); if (parent != null) { parent.removeView(layout4);
					
				} container.addView(layout4); }
			
			else if (position == 4) { ViewGroup parent = (ViewGroup) layout5.getParent(); if (parent != null) { parent.removeView(layout5);
					
				} container.addView(layout5); }
			
			
			
			 collection.addView(v, 0); return v; 
			
		} @Override public void destroyItem(ViewGroup collection, int position, Object view) { collection.removeView((View) view); trash.addView((View) view);
			
		} @Override public CharSequence getPageTitle(int position) { switch (position) { case 0: return "FOLLOWING"; case 1: return "EXPLORE"; case 2: return "CHANTS";
				case 3: return "EBOOKS";
				case 4: return "QUOTES";
				 default: return null; }
			
			
		} @Override public boolean isViewFromObject(View arg0, Object arg1) { return arg0 == ((View) arg1);} @Override public Parcelable saveState() { return null; } } androidx.viewpager.widget.ViewPager viewPager;  private void foo() {
	}
	
	
	public void _Song3 () {
		map1 = new HashMap<>();
		map1.put("name", "Samsong");
		map1.put("ministry", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "more_11");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Sinach");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "sinach2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Solomon Lange");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "more_5");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Sonnie Badu");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "more_6");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Steve Crown");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "steve_crown_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Tim Godfrey");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "tim_godfrey_2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Tope Alabi");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "tope_alabi_2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Travis Greene");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "travis_greene_4");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Victoria Orenze");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "victoria_orenze");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
	}
	
	
	public void _Cat1 () {
		map1 = new HashMap<>();
		map1.put("name", "Vehicles");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Properties");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Phones and Tablets");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Electronics & Gadgets");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Home & Appliances");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Health & Body Care");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Fashion");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Shoes");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Hobbies, Art & Sports");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Seeking Work - CV's");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Services");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
	}
	
	
	public void _Cat2 () {
		map1 = new HashMap<>();
		map1.put("name", "Jobs");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Babies & kids");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Animals & Pets");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Food Market & Agriculture");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Equipments & Tools");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Health & Body Care");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Repair & Construction");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
	}
	
	
	public void _rippleRoundStroke (final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.custm, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout linear10 = (LinearLayout) _view.findViewById(R.id.linear10);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final HorizontalScrollView hscroll1 = (HorizontalScrollView) _view.findViewById(R.id.hscroll1);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final ImageView imageview4 = (ImageView) _view.findViewById(R.id.imageview4);
			final ImageView imageview5 = (ImageView) _view.findViewById(R.id.imageview5);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)0, 0xFFFFFFFF, 0xFF4CAF50));
			button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom2, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			textview1.setText(_data.get((int)_position).get("name").toString());
			
			return _view;
		}
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.custh, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear10 = (LinearLayout) _view.findViewById(R.id.linear10);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout horiz_linear = (LinearLayout) _view.findViewById(R.id.horiz_linear);
			final LinearLayout vert_linear6 = (LinearLayout) _view.findViewById(R.id.vert_linear6);
			final LinearLayout linear43 = (LinearLayout) _view.findViewById(R.id.linear43);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final HorizontalScrollView hscroll1 = (HorizontalScrollView) _view.findViewById(R.id.hscroll1);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final LinearLayout l1 = (LinearLayout) _view.findViewById(R.id.l1);
			final LinearLayout l2 = (LinearLayout) _view.findViewById(R.id.l2);
			final LinearLayout l3 = (LinearLayout) _view.findViewById(R.id.l3);
			final LinearLayout l4 = (LinearLayout) _view.findViewById(R.id.l4);
			final LinearLayout l5 = (LinearLayout) _view.findViewById(R.id.l5);
			final androidx.cardview.widget.CardView lc1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.lc1);
			final LinearLayout hh1 = (LinearLayout) _view.findViewById(R.id.hh1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView textview13 = (TextView) _view.findViewById(R.id.textview13);
			final TextView textview6 = (TextView) _view.findViewById(R.id.textview6);
			final TextView textview18 = (TextView) _view.findViewById(R.id.textview18);
			final TextView textview19 = (TextView) _view.findViewById(R.id.textview19);
			final androidx.cardview.widget.CardView hc2 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc2);
			final LinearLayout hh2 = (LinearLayout) _view.findViewById(R.id.hh2);
			final ImageView imageview7 = (ImageView) _view.findViewById(R.id.imageview7);
			final TextView textview14 = (TextView) _view.findViewById(R.id.textview14);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview20 = (TextView) _view.findViewById(R.id.textview20);
			final TextView textview21 = (TextView) _view.findViewById(R.id.textview21);
			final androidx.cardview.widget.CardView hc3 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc3);
			final LinearLayout hh3 = (LinearLayout) _view.findViewById(R.id.hh3);
			final ImageView imageview11 = (ImageView) _view.findViewById(R.id.imageview11);
			final TextView textview15 = (TextView) _view.findViewById(R.id.textview15);
			final TextView textview8 = (TextView) _view.findViewById(R.id.textview8);
			final TextView textview22 = (TextView) _view.findViewById(R.id.textview22);
			final TextView textview23 = (TextView) _view.findViewById(R.id.textview23);
			final androidx.cardview.widget.CardView hc4 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc4);
			final LinearLayout hh4 = (LinearLayout) _view.findViewById(R.id.hh4);
			final ImageView imageview12 = (ImageView) _view.findViewById(R.id.imageview12);
			final TextView textview16 = (TextView) _view.findViewById(R.id.textview16);
			final TextView textview9 = (TextView) _view.findViewById(R.id.textview9);
			final TextView textview24 = (TextView) _view.findViewById(R.id.textview24);
			final TextView textview25 = (TextView) _view.findViewById(R.id.textview25);
			final androidx.cardview.widget.CardView hc5 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc5);
			final LinearLayout hh5 = (LinearLayout) _view.findViewById(R.id.hh5);
			final ImageView imageview13 = (ImageView) _view.findViewById(R.id.imageview13);
			final TextView textview17 = (TextView) _view.findViewById(R.id.textview17);
			final TextView textview10 = (TextView) _view.findViewById(R.id.textview10);
			final TextView textview26 = (TextView) _view.findViewById(R.id.textview26);
			final TextView textview27 = (TextView) _view.findViewById(R.id.textview27);
			final LinearLayout v1 = (LinearLayout) _view.findViewById(R.id.v1);
			final LinearLayout v2 = (LinearLayout) _view.findViewById(R.id.v2);
			final LinearLayout linear30 = (LinearLayout) _view.findViewById(R.id.linear30);
			final LinearLayout linear32 = (LinearLayout) _view.findViewById(R.id.linear32);
			final androidx.cardview.widget.CardView cardview10 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview10);
			final LinearLayout linear31 = (LinearLayout) _view.findViewById(R.id.linear31);
			final ImageView imageview14 = (ImageView) _view.findViewById(R.id.imageview14);
			final TextView textview5 = (TextView) _view.findViewById(R.id.textview5);
			final androidx.cardview.widget.CardView cardview11 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview11);
			final LinearLayout linear33 = (LinearLayout) _view.findViewById(R.id.linear33);
			final ImageView imageview15 = (ImageView) _view.findViewById(R.id.imageview15);
			final TextView textview4 = (TextView) _view.findViewById(R.id.textview4);
			final LinearLayout linear39 = (LinearLayout) _view.findViewById(R.id.linear39);
			final LinearLayout linear40 = (LinearLayout) _view.findViewById(R.id.linear40);
			final androidx.cardview.widget.CardView cardview14 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview14);
			final LinearLayout linear41 = (LinearLayout) _view.findViewById(R.id.linear41);
			final ImageView imageview18 = (ImageView) _view.findViewById(R.id.imageview18);
			final TextView textview11 = (TextView) _view.findViewById(R.id.textview11);
			final androidx.cardview.widget.CardView cardview15 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview15);
			final LinearLayout linear42 = (LinearLayout) _view.findViewById(R.id.linear42);
			final ImageView imageview19 = (ImageView) _view.findViewById(R.id.imageview19);
			final TextView textview12 = (TextView) _view.findViewById(R.id.textview12);
			final LinearLayout linear44 = (LinearLayout) _view.findViewById(R.id.linear44);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final HorizontalScrollView hscroll2 = (HorizontalScrollView) _view.findViewById(R.id.hscroll2);
			final LinearLayout linear45 = (LinearLayout) _view.findViewById(R.id.linear45);
			final TextView textview28 = (TextView) _view.findViewById(R.id.textview28);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)2, 0xFF43A047, 0xFF4CAF50));
			button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), CustomerActivity.class);
					startActivity(i);
				}
			});
			textview2.setElevation((float)5);
			textview1.setElevation((float)5);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Gridview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom2, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}